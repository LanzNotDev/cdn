/*
Terimakasih Telah Menggunakan Script ini
Base By : Lezz DcodeR
Optimalization By : LanzOffcial

Dukung Kami dengan membiarkan credit ini tetap ada!
*/

const fs = require('fs')
const chalk = require('chalk')

//Settings
global.owner = "6287862058684"
global.ownername = "ʟᴀɴᴢᴇxᴇ"
global.namabot = "LanzXBOT"
global.botversion = "V1"
global.linkgc = "https://whatsapp.com/channel/0029Vb7BMXC9sBI8pXjrEY05"
global.idGc = "120363404782325678@newsletter"
global.linkSaluran = "https://whatsapp.com/channel/0029Vb7BMXC9sBI8pXjrEY05"
global.idSaluran = "120363404782325678@newsletter"
global.namaSaluran = global.ownername + " | Saluran WhatsApp"
global.simbol = "⭔"

//Thumbnail
global.imgthumb = "https://img12.pixhost.to/images/1184/580046771_imgtmp.jpg"

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})